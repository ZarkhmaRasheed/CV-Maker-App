import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, Alert } from 'react-native';
import tw from 'twrnc';
import {supabase} from './supabase'; // Ensure this file contains your Supabase client initialization

const Skills = ({ navigation }) => {
  const [skills, setSkills] = useState([{ skill: '' }]);

  const handleAddSkill = () => {
    setSkills([...skills, { skill: '' }]);
  };

  const handleChange = (index, value) => {
    const updatedSkills = [...skills];
    updatedSkills[index].skill = value;
    setSkills(updatedSkills);
  };

  const handleSubmit = async (index) => {
    const skill = skills[index].skill;
    if (!skill) {
      Alert.alert('Error', 'Please fill out the skill field.');
      return;
    }

    try {
      // Insert the skill into the 'Skills' table in Supabase
      const { data, error } = await supabase
        .from('Skills') // Ensure your table name is correct
        .insert([{ skill: skill }]);

      if (error) {
        throw error;
      }

      Alert.alert('Success', `Skill ${index + 1} added successfully!`);
    } catch (error) {
      Alert.alert('Error', error.message);
    }
    navigation.navigate('Hobby'); 
  };

  return (
    <View style={tw`flex-1 bg-gray-100 p-4`}>
      <ScrollView contentContainerStyle={tw`pb-10`}>
        {skills.map((skill, index) => (
          <View key={index} style={tw`mb-6 bg-white p-6 rounded-lg shadow-lg`}>
            <Text style={tw`text-lg font-bold text-blue-800 mb-4`}>Skill {index + 1}</Text>
            
            {/* Skill Input */}
            <Text style={tw`text-gray-800 font-semibold mb-2`}>Skill</Text>
            <TextInput
              style={tw`p-3 border border-gray-300 rounded mb-4`}
              placeholder="Enter your skill"
              value={skill.skill}
              onChangeText={(text) => handleChange(index, text)}
            />

            {/* Submit Button for each Skill */}
            <TouchableOpacity
              onPress={() => handleSubmit(index)}
              style={tw`bg-blue-500 px-4 py-3 rounded shadow-lg`}
            >
              <Text style={tw`text-white font-bold text-center`}>Submit Skill</Text>
            </TouchableOpacity>
          </View>
        ))}

        {/* Add Skill Button */}
        <TouchableOpacity
          onPress={handleAddSkill}
          style={tw`bg-green-500 px-4 py-3 rounded shadow-lg mt-6`}
        >
          <Text style={tw`text-white font-bold text-center`}>Add Skill</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

export default Skills;
