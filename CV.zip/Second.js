import React from 'react';
import { View, Text, TouchableOpacity, ScrollView } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import tw from 'twrnc';
import { useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';

const Second = () => {
  const navigation = useNavigation();

  const handlePress = (screen) => {
    if (screen) {
      navigation.navigate(screen); 
    }
  };

  return (
    <View style={tw`flex-1 bg-blue-50`}>
      <SafeAreaView style={tw`flex-1 bg-blue-50`}>
      {/* Header */}
      <View style={tw`flex-row justify-between items-center px-4 py-6 bg-blue-600 shadow-md mt-4`}>
    <Text style={tw`text-lg font-bold text-white`}>Resume Builder</Text>
    <FontAwesome name="search" size={24} color="white" />
  </View>

      {/* Welcome Section */}
      <View style={tw`px-4 py-6 bg-blue-100`}>
        <Text style={tw`text-lg font-semibold text-gray-700 mb-2`}>Welcome Back,</Text>
        <Text style={tw`text-2xl font-bold text-blue-800`}>    Zarkhman Rasheed</Text>
        <Text style={tw`text-sm text-gray-500 mt-2`}>Get started by exploring your options below.</Text>
      </View>

      {/* Options Cards */}
      <ScrollView style={tw`px-4 mt-4`}>
        {[
          { title: 'Create Resume', desc: 'Start building your resume', icon: 'edit', screen: 'IntroPage' },
          { title: 'View Resume', desc: 'Preview your existing resumes', icon: 'eye', screen: 'CurriculumVitae' },
          { title: 'Downloads', desc: 'Access your downloaded resumes', icon: 'download', screen: 'CurriculumVitae' },
          { title: 'Share', desc: 'Share your resume with others', icon: 'share', screen: 'Projects' },
        ].map((option, index) => (
          <TouchableOpacity
            key={index}
            style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg flex-row justify-between items-center`}
            onPress={() => handlePress(option.screen)} 
          >
            <View>
              <Text style={tw`text-lg font-semibold text-gray-800`}>{option.title}</Text>
              <Text style={tw`text-sm text-gray-500`}>{option.desc}</Text>
            </View>
            <FontAwesome name={option.icon} size={24} color="blue" />
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Bottom Navigation */}
      <View style={tw`flex-row justify-around items-center bg-blue-600 py-4 shadow-md`}>
        <TouchableOpacity>
          <FontAwesome name="home" size={24} color="white" />
        </TouchableOpacity>
        <TouchableOpacity>
          <FontAwesome name="file" size={24} color="white" />
        </TouchableOpacity>
        <TouchableOpacity>
          <FontAwesome name="cog" size={24} color="white" />
        </TouchableOpacity>
      </View>
      </SafeAreaView>
    </View>
    
  );
};

export default Second;
