import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, ScrollView, Image } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import tw from 'twrnc';
import { supabase } from './supabase';  // Import Supabase client
import * as ImagePicker from 'expo-image-picker';  // Import the image picker

const IntroPage = ({ navigation }) => {
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [objective, setObjective] = useState('');
  const [image, setImage] = useState(null); // State to store the selected image

  // Request permission for image picker
  const requestPermission = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission required', 'Sorry, we need camera roll permissions to select a picture!');
    }
  };

  // Handle image picking
  const pickImage = async () => {
    await requestPermission();

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 1,
    });

    if (!result.canceled) {
      setImage(result.assets[0].uri); // Store the selected image URI
    }
  };

  // Handle form submission and save data to Supabase
  const handleSubmit = async () => {
    if (!name || !mobile || !email || !objective || !image) {
      Alert.alert('Error', 'All fields are required!');
      return;
    }

    try {
      const { data, error } = await supabase
        .from('UserInfo') // Replace 'UserInfo' with your table name
        .insert([{ name, mobile, email, objective, image }]);

      if (error) {
        Alert.alert('Error', 'Failed to submit the form');
        console.error('Error inserting data:', error);
      } else {
       
        setName('');
        setMobile('');
        setEmail('');
        setObjective('');
        setImage(null); // Clear the image after submission

        navigation.navigate('Degree'); 
      }
    } catch (err) {
      console.error('Unexpected error:', err);
      Alert.alert('Error', 'An unexpected error occurred');
    }
  };

  return (
    <View style={tw`flex-1 bg-blue-50`}>
      <ScrollView contentContainerStyle={tw`p-4`}>
        {/* Header */}
        <View style={tw`flex-row justify-between items-center mb-6`}>
          <Text style={tw`text-lg font-bold text-blue-800`}>User Information</Text>
          <FontAwesome name="user-circle" size={24} color="blue" />
        </View>

        {/* Input Fields */}
        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>Name</Text>
          <TextInput
            style={tw`p-3 border border-gray-300 rounded mb-4`}
            placeholder="Enter your name"
            value={name}
            onChangeText={setName}
          />
        </View>

        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>Mobile Number</Text>
          <TextInput
            style={tw`p-3 border border-gray-300 rounded mb-4`}
            placeholder="Enter your mobile number"
            value={mobile}
            keyboardType="phone-pad"
            onChangeText={setMobile}
          />
        </View>

        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>Email Address</Text>
          <TextInput
            style={tw`p-3 border border-gray-300 rounded mb-4`}
            placeholder="Enter your email address"
            value={email}
            keyboardType="email-address"
            onChangeText={setEmail}
          />
        </View>

        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>Objective</Text>
          <TextInput
            style={tw`p-3 border border-gray-300 rounded mb-4`}
            placeholder="Enter your objective"
            value={objective}
            multiline
            onChangeText={setObjective}
          />
        </View>

        {/* Picture Field */}
        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>Profile Picture</Text>
          <TouchableOpacity onPress={pickImage} style={tw`bg-blue-500 px-4 py-3 rounded flex-row items-center justify-center`}>
            <FontAwesome name="image" size={20} color="white" />
            <Text style={tw`text-white font-bold ml-2`}>Select Picture</Text>
          </TouchableOpacity>

          {/* Display selected image */}
          {image && (
            <Image source={{ uri: image }} style={tw`mt-4 w-32 h-32 rounded-lg`} />
          )}
        </View>

        {/* Submit Button */}
        <TouchableOpacity
          onPress={handleSubmit}
          style={tw`bg-blue-500 px-4 py-3 rounded shadow-lg flex-row items-center justify-center`}
        >
          <FontAwesome name="check-circle" size={20} color="white" />
          <Text style={tw`text-white font-bold ml-2`}>Next</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

export default IntroPage;
