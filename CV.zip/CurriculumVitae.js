import React, { useState, useEffect } from 'react';
import { View, Text, Image, ScrollView, ActivityIndicator, Button, StyleSheet, Alert } from 'react-native';
import tw from 'twrnc';
import { supabase } from './supabase'; // Ensure your Supabase client is properly initialized
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';

const CurriculumVitae = () => {
  const [projects, setProjects] = useState([]);
  const [jobExperience, setJobExperience] = useState([]);
  const [profile, setProfile] = useState({});
  const [degrees, setDegrees] = useState([]);
  const [hobbies, setHobbies] = useState([]);
  const [interests, setInterests] = useState([]);
  const [userInfo, setUserInfo] = useState({});
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      setLoading(true);

      // Fetch the most recent profile data
      const { data: profileData, error: profileError } = await supabase
        .from('personal_details')
        .select('*')
        .order('id', { ascending: false })
        .limit(1)
        .single();
      if (profileError) throw profileError;
      setProfile(profileData || {});

      // Fetch other data (projects, job experience, etc.) in a similar way

      // Fetch user info (if separate)
      const { data: userInfoData, error: userInfoError } = await supabase
        .from('UserInfo')
        .select('*')
        .order('id', { ascending: false })
        .limit(1)
        .single();
      if (userInfoError) throw userInfoError;
      setUserInfo(userInfoData || {});

      // Fetch the most recent project
      const { data: projectsData, error: projectsError } = await supabase
        .from('Projects')
        .select('*')
        .order('id', { ascending: false })
        .limit(1);
      if (projectsError) throw projectsError;
      setProjects(projectsData || []);

      const { data: jobExperienceData, error: jobExperienceError } = await supabase
        .from('JobExperience')
        .select('*')
        .order('id', { ascending: false })
        .limit(1);
      if (jobExperienceError) throw jobExperienceError;
      setJobExperience(jobExperienceData || []);

      const { data: degreesData, error: degreesError } = await supabase
        .from('Degrees')
        .select('*')
        .order('id', { ascending: false })
        .limit(1);
      if (degreesError) throw degreesError;
      setDegrees(degreesData || []);

      // Fetch the most recent hobby
      const { data: hobbiesData, error: hobbiesError } = await supabase
        .from('hobbies')
        .select('*')
        .order('id', { ascending: false })
        .limit(1);
      if (hobbiesError) throw hobbiesError;
      setHobbies(hobbiesData || []);

      // Fetch the most recent interest
      const { data: interestsData, error: interestsError } = await supabase
        .from('Interests')
        .select('*')
        .order('id', { ascending: false })
        .limit(1);
      if (interestsError) throw interestsError;
      setInterests(interestsData || []);

      // Fetch user info (if separate)

    } catch (error) {
      console.error('Error fetching data:', error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const generatePDF = async () => {
    // HTML content for the PDF
    const htmlContent = `
   <img 
  src="${userInfo.image}" 
  alt="." 
  style="
    width: 200px; 
    height: 200px; 
    border-radius: 50%; 
    border: 4px solid white; 
    display: block; 
    margin: 0 auto;">

  <div style="
    max-width: 800px; 
    margin: 20px auto; 
    padding: 30px; 
    border: 1px solid #ddd; 
    border-radius: 10px; 
    font-family: Arial, sans-serif; 
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
    background-color: #ffffff;">
    
    <!-- Header -->
    <h1 style="
      text-align: center; 
      color: #4A90E2; 
      font-size: 28px; 
      margin-bottom: 20px; 
      text-transform: uppercase;">Curriculum Vitae</h1>
    
    <!-- User Info Section -->
    <h2 style="
      color: #4A90E2; 
      font-size: 20px; 
      border-bottom: 2px solid #4A90E2; 
      padding-bottom: 5px; 
      margin-bottom: 10px;">User Info</h2>
    <div style="padding: 10px; line-height: 1.6;">

     <p><strong>Name:</strong> ${userInfo.name || 'N/A'}</p>
      <p><strong>Email:</strong> ${userInfo.email || 'N/A'}</p>
      <p><strong>Mobile:</strong> ${userInfo.mobile || 'N/A'}</p>
      <p><strong>Objective:</strong> ${userInfo.objective || 'N/A'}</p>
    </div>
    
    <!-- Profile Details -->
    <h2 style="
      color: #4A90E2; 
      font-size: 20px; 
      border-bottom: 2px solid #4A90E2; 
      padding-bottom: 5px; 
      margin-bottom: 10px;">Profile Details</h2>
    <div style="padding: 10px; line-height: 1.6;">
      <p><strong>Father's Name:</strong> ${profile.father_name || 'N/A'}</p>
      <p><strong>Date of Birth:</strong> ${profile.dob || 'N/A'}</p>
      <p><strong>Gender:</strong> ${profile.gender || 'N/A'}</p>
      <p><strong>Marital Status:</strong> ${profile.marital_status || 'N/A'}</p>
      <p><strong>Nationality:</strong> ${profile.nationality || 'N/A'}</p>
      <p><strong>Languages Known:</strong> ${profile.languages_known || 'N/A'}</p>
    </div>

    <!-- Projects -->
    <h2 style="
      color: #4A90E2; 
      font-size: 20px; 
      border-bottom: 2px solid #4A90E2; 
      padding-bottom: 5px; 
      margin-bottom: 10px;">Projects</h2>
    <div style="padding: 10px; line-height: 1.6;">
      ${projects.map(project => `
        <p><strong>Title:</strong> ${project.title || 'N/A'}</p>
        <p><strong>Duration:</strong> ${project.duration || 'N/A'}</p>
        <p><strong>Description:</strong> ${project.description || 'N/A'}</p>
        <p><strong>Role:</strong> ${project.role || 'N/A'}</p>
      `).join('<hr style="margin: 10px 0; border: 0; border-top: 1px solid #ddd;">')}
    </div>

    <!-- Job Experience -->
    <h2 style="
      color: #4A90E2; 
      font-size: 20px; 
      border-bottom: 2px solid #4A90E2; 
      padding-bottom: 5px; 
      margin-bottom: 10px;">Job Experience</h2>
    <div style="padding: 10px; line-height: 1.6;">
      ${jobExperience.map(job => `
       
        <p><strong>Company:</strong> ${job.company || 'N/A'}</p>
          <p><strong>Role:</strong> ${job.role || 'N/A'}</p>
        <p><strong>Start Year:</strong> ${job.start_year || 'N/A'}</p>
         <p><strong>End Year:</strong> ${job.end_year || 'N/A'}</p>
        <p><strong>Description:</strong> ${job.description || 'N/A'}</p>
      `).join('<hr style="margin: 10px 0; border: 0; border-top: 1px solid #ddd;">')}
    </div>

    <!-- Degrees -->
    <h2 style="
      color: #4A90E2; 
      font-size: 20px; 
      border-bottom: 2px solid #4A90E2; 
      padding-bottom: 5px; 
      margin-bottom: 10px;">Degrees</h2>
    <div style="padding: 10px; line-height: 1.6;">
      ${degrees.map(degree => `
        <p><strong>Degree:</strong> ${degree.course || 'N/A'}</p>
        <p><strong>Institution:</strong> ${degree.school || 'N/A'}</p>
        <p><strong>CGPA:</strong> ${degree.percentage || 'N/A'}</p>
          <p><strong>Year:</strong> ${degree.year || 'N/A'}</p>
      `).join('<hr style="margin: 10px 0; border: 0; border-top: 1px solid #ddd;">')}
    </div>

    <!-- Hobbies -->
    <h2 style="
      color: #4A90E2; 
      font-size: 20px; 
      border-bottom: 2px solid #4A90E2; 
      padding-bottom: 5px; 
      margin-bottom: 10px;">Hobbies</h2>
    <div style="padding: 10px; line-height: 1.6;">
      ${hobbies.map(hobby => `
        <p><strong>Hobby:</strong> ${hobby.hobby || 'N/A'}</p>
      `).join('')}
    </div>

    <!-- Interests -->
    <h2 style="
      color: #4A90E2; 
      font-size: 20px; 
      border-bottom: 2px solid #4A90E2; 
      padding-bottom: 5px; 
      margin-bottom: 10px;">Interests</h2>
    <div style="padding: 10px; line-height: 1.6;">
      ${interests.map(interest => `
        <p><strong>Interest:</strong> ${interest.interest || 'N/A'}</p>
      `).join('')}
    </div>
  </div>
`;

    try {
      // Generate PDF file
      const { uri } = await Print.printToFileAsync({ html: htmlContent });
      Alert.alert('PDF Generated', 'PDF has been generated.');

      // Check if sharing is available
      if (await Sharing.isAvailableAsync()) {
        // Open or share the PDF file
        await Sharing.shareAsync(uri);
      } else {
        Alert.alert('Sharing not available', 'This device does not support file sharing.');
      }

      console.log('PDF saved to:', uri); // You can also log the URI for debugging

    } catch (error) {
      Alert.alert('Error', 'Failed to generate PDF');
      console.error(error);
    }
  };

  const styles = StyleSheet.create({
    textCenter: { textAlign: 'center', padding: 5 },
    bgGray: { backgroundColor: '#f0f0f0' },
    row: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 5 },
    label: { fontWeight: 'bold', color: '#4A4A4A' },
    value: { color: '#707070' },
  });

  const renderRow = (label, value) => (
    <View style={styles.row}>
      <Text style={styles.label}>{label}:</Text>
      <Text style={styles.value}>{value || 'N/A'}</Text>
    </View>
  );

  return (
    <ScrollView style={tw`bg-gray-100 flex-1`}>
      <View style={tw`bg-blue-500 p-6 items-center`}>
        <Image
          source={{ uri: userInfo.image }}
          style={tw`w-50 h-50 rounded-full border-4 border-white`}
        />

        <Text style={tw`text-white text-2xl font-bold mt-4`}>{userInfo.name}</Text>
        <Text style={tw`text-white text-lg`}>{userInfo.email}</Text>
      </View>

      <View style={tw`p-4`}>
        <Text style={tw`text-xl font-bold text-blue-700 mb-2`}>User Info</Text>

        <Text style={tw`text-gray-700`}>
          <Text style={tw`font-bold`}>Email:    </Text> {userInfo.email || 'N/A'}
        </Text>
        <Text style={tw`text-gray-700`}>
          <Text style={tw`font-bold`}>Mobile:    </Text> {userInfo.mobile || 'N/A'}
        </Text>
        <Text style={tw`text-gray-700`}>
          <Text style={tw`font-bold`}>Objective:    </Text> {userInfo.objective || 'N/A'}
        </Text>
      </View>

      <View style={tw`p-4 mr-5`}>
        <Text style={tw`text-xl font-bold text-blue-700 mb-2`}>Profile Details</Text>
        <Text style={tw`text-gray-700`}>
          <Text style={tw`font-bold`}>Father's Name:    </Text> {profile.father_name || 'N/A'}
        </Text>
        <Text style={tw`text-gray-700`}>
          <Text style={tw`font-bold`}>Date of Birth:    </Text> {profile.dob || 'N/A'}
        </Text>
        <Text style={tw`text-gray-700`}>
          <Text style={tw`font-bold`}>Gender:    </Text> {profile.gender || 'N/A'}
        </Text>
        <Text style={tw`text-gray-700`}>
          <Text style={tw`font-bold`}>Marital Status:    </Text> {profile.marital_status || 'N/A'}
        </Text>
        <Text style={tw`text-gray-700`}>
          <Text style={tw`font-bold`}>Nationality:    </Text> {profile.nationality || 'N/A'}
        </Text>
        <Text style={tw`text-gray-700`}>
          <Text style={tw`font-bold`}>Languages Known:    </Text> {profile.languages_known || 'N/A'}
        </Text>
      </View>

      <View style={tw`p-4`}>
        <Text style={tw`text-xl font-bold text-blue-700 mb-2`}>Projects</Text>
        {loading ? <ActivityIndicator size="large" color="#0000ff" /> :
          projects.map((project, index) => (
            <View key={index} style={tw`p-4 bg-white rounded-lg shadow mb-4`}>
              {renderRow('Title', project.title)}
              {renderRow('Duration', project.duration)}
              {renderRow('Description', project.description)}
              {renderRow('Role', project.role)}
              {renderRow('Team Members', project.team_members)}
            </View>
          ))
        }
      </View>
      <View style={tw`p-4`}>
        <Text style={tw`text-xl font-bold text-blue-700 mb-2`}>Degrees</Text>
        {loading ? <ActivityIndicator size="large" color="#0000ff" /> :
          degrees.map((degree, index) => (
            <View key={index} style={tw`p-4 bg-white rounded-lg shadow mb-4`}>
              {renderRow('Course', degree.course)}
              {renderRow('School', degree.school)}
             
              {renderRow('Graduation Year', degree.year)}
            </View>
          ))
        }
      </View>

      <View style={tw`p-4`}>
        <Text style={tw`text-xl font-bold text-blue-700 mb-2`}>Hobbies</Text>
        {loading ? <ActivityIndicator size="large" color="#0000ff" /> :
          hobbies.map((hobby, index) => (
            <View key={index} style={tw`p-4 bg-white rounded-lg shadow mb-4`}>
              {renderRow('Hobby', hobby.hobby)}
            </View>
          ))
        }
      </View>

      <View style={tw`p-4`}>
        <Text style={tw`text-xl font-bold text-blue-700 mb-2`}>Interests</Text>
        {loading ? <ActivityIndicator size="large" color="#0000ff" /> :
          interests.map((interest, index) => (
            <View key={index} style={tw`p-4 bg-white rounded-lg shadow mb-4`}>
              {renderRow('Interest', interest.interest)}
            </View>
          ))
        }
      </View>

      <View style={tw`p-4`}>
        <Text style={tw`text-xl font-bold text-blue-700 mb-2`}>Job Experience</Text>
        {loading ? <ActivityIndicator size="large" color="#0000ff" /> :
          jobExperience.map((job, index) => (
            <View key={index} style={tw`p-4 bg-white rounded-lg shadow mb-4`}>
              {renderRow('Company', job.company)}
              {renderRow('Role', job.role)}
              {renderRow('Description', job.description)}
              {renderRow('Start Month', job.start_month)}
              {renderRow('Start Year', job.start_year)}
              {renderRow('End Month', job.end_month)}
              {renderRow('End Year', job.end_year)}
            </View>
          ))
        }
      </View>
      {/* Include similar sections for Projects, Job Experience, Degrees, Hobbies, Interests */}

      {/* Generate PDF Button */}
      <View style={tw`p-4 mt-4`}>
        <Button title="Generate PDF" onPress={generatePDF} color="blue" />
      </View>
    </ScrollView>
  );
};

export default CurriculumVitae;
