import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, ScrollView } from 'react-native';
import tw from 'twrnc';
import {supabase} from './supabase'; // Import the Supabase client

const Projects = ({ navigation }) => {
  const [projects, setProjects] = useState([
    { title: '', description: '', duration: '', role: '', teamMembers: '' },
  ]);

  const handleAddProject = () => {
    setProjects([
      ...projects,
      { title: '', description: '', duration: '', role: '', teamMembers: '' },
    ]);
  };

  const handleChange = (index, field, value) => {
    const updatedProjects = [...projects];
    updatedProjects[index][field] = value;
    setProjects(updatedProjects);
  };

  const handleSubmit = async (index) => {
    const project = projects[index];

    if (!project.title || !project.description || !project.duration || !project.role || !project.teamMembers) {
      Alert.alert('Error', 'Please fill out all fields.');
      return;
    }

    try {
      const { data, error } = await supabase
        .from('Projects') // Ensure this is your table name
        .insert([
          {
            title: project.title,
            description: project.description,
            duration: project.duration,
            role: project.role,
            team_members: project.teamMembers, // Ensure your column names are correct
            
          },
        ]);

      if (error) {
        console.error('Error inserting project:', error);
        Alert.alert('Error', 'Failed to add the project.');
      } else {
       
        navigation.navigate('InterestPage'); 
        setProjects([
          ...projects.slice(0, index),
          { title: '', description: '', duration: '', role: '', teamMembers: '' }, // Reset the project after submission
          ...projects.slice(index + 1),
        ]);
      }
    } catch (err) {
      console.error('Unexpected error:', err);
      Alert.alert('Error', 'An unexpected error occurred');
    }
  };

  return (
    <View style={tw`flex-1 bg-gray-100 p-4`}>
      <ScrollView contentContainerStyle={tw`pb-10`}>
        {projects.map((project, index) => (
          <View key={index} style={tw`mb-6 bg-white p-6 rounded-lg shadow-lg`}>
            <Text style={tw`text-lg font-bold text-blue-800 mb-4`}>Project {index + 1}</Text>

            {/* Project Title */}
            <Text style={tw`text-gray-800 font-semibold mb-2`}>Project Title</Text>
            <TextInput
              style={tw`p-3 border border-gray-300 rounded mb-4`}
              placeholder="Enter project title"
              value={project.title}
              onChangeText={(text) => handleChange(index, 'title', text)}
            />

            {/* Project Description */}
            <Text style={tw`text-gray-800 font-semibold mb-2`}>Project Description</Text>
            <TextInput
              style={tw`p-3 border border-gray-300 rounded mb-4`}
              placeholder="Enter project description"
              value={project.description}
              onChangeText={(text) => handleChange(index, 'description', text)}
            />

            {/* Project Duration */}
            <Text style={tw`text-gray-800 font-semibold mb-2`}>Project Duration</Text>
            <TextInput
              style={tw`p-3 border border-gray-300 rounded mb-4`}
              placeholder="Enter project duration"
              value={project.duration}
              onChangeText={(text) => handleChange(index, 'duration', text)}
            />

            {/* Role */}
            <Text style={tw`text-gray-800 font-semibold mb-2`}>Role</Text>
            <TextInput
              style={tw`p-3 border border-gray-300 rounded mb-4`}
              placeholder="Enter your role"
              value={project.role}
              onChangeText={(text) => handleChange(index, 'role', text)}
            />

            {/* Team Members */}
            <Text style={tw`text-gray-800 font-semibold mb-2`}>Team Members</Text>
            <TextInput
              style={tw`p-3 border border-gray-300 rounded mb-4`}
              placeholder="Enter team members"
              value={project.teamMembers}
              onChangeText={(text) => handleChange(index, 'teamMembers', text)}
            />

            {/* Submit Button for each Project */}
            <TouchableOpacity
              onPress={() => handleSubmit(index)}
              style={tw`bg-blue-500 px-4 py-3 rounded shadow-lg`}
            >
              <Text style={tw`text-white font-bold text-center`}>Submit Project</Text>
            </TouchableOpacity>
          </View>
        ))}

        {/* Add Project Button */}
        <TouchableOpacity
          onPress={handleAddProject}
          style={tw`bg-green-500 px-4 py-3 rounded shadow-lg mt-6`}
        >
          <Text style={tw`text-white font-bold text-center`}>Add Project</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

export default Projects;

