import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, ScrollView } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import tw from 'twrnc';
import { supabase } from './supabase'; // Import the Supabase client

const Degree = ({ navigation }) =>  {
  const [course, setCourse] = useState('');
  const [school, setSchool] = useState('');
  const [percentage, setPercentage] = useState('');
  const [year, setYear] = useState('');

  // Handle form submission and save data to Supabase
  const handleSubmit = async () => {
    if (!course || !school || !percentage || !year) {
      Alert.alert('Error', 'All fields are required!');
      return;
    }

    try {
      // Inserting data into the Supabase table 'Degrees' (make sure to create this table in your Supabase database)
      const { data, error } = await supabase
        .from('Degrees') // Replace 'Degrees' with your table name in Supabase
        .insert([
          { course, school, percentage, year },
        ]);

      if (error) {
        Alert.alert('Error', 'Failed to submit the form');
        console.error('Error inserting data:', error);
      } else {
       
        setCourse('');
        setSchool('');
        setPercentage('');
        setYear('');

        navigation.navigate('JobExperience'); 
      }
    } catch (err) {
      console.error('Unexpected error:', err);
      Alert.alert('Error', 'An unexpected error occurred');
    }
  };

  return (
    <View style={tw`flex-1 bg-blue-50`}>
      <ScrollView contentContainerStyle={tw`p-4`}>
        {/* Header */}
        <View style={tw`mt-7 flex-row justify-between items-center mb-6`}>
          <Text style={tw`text-lg font-bold text-blue-800`}>Add Degree</Text>
          <FontAwesome name="graduation-cap" size={24} color="blue" />
        </View>

        {/* Input Fields */}
        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>Course/Degree</Text>
          <TextInput
            style={tw`p-3 border border-gray-300 rounded mb-4`}
            placeholder="Enter your course or degree"
            value={course}
            onChangeText={setCourse}
          />
        </View>

        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>School/University/College</Text>
          <TextInput
            style={tw`p-3 border border-gray-300 rounded mb-4`}
            placeholder="Enter the name of your school/uni/college"
            value={school}
            onChangeText={setSchool}
          />
        </View>

        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>Percentage/GPA</Text>
          <TextInput
            style={tw`p-3 border border-gray-300 rounded mb-4`}
            placeholder="Enter your percentage or GPA"
            value={percentage}
            keyboardType="numeric"
            onChangeText={setPercentage}
          />
        </View>

        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>Year of Passing</Text>
          <TextInput
            style={tw`p-3 border border-gray-300 rounded mb-4`}
            placeholder="Enter the year you graduated"
            value={year}
            keyboardType="numeric"
            onChangeText={setYear}
          />
        </View>

        {/* Submit Button */}
        <TouchableOpacity
          onPress={handleSubmit}
          style={tw`bg-blue-500 px-4 py-3 rounded shadow-lg flex-row items-center justify-center`}
        >
          <FontAwesome name="check-circle" size={20} color="white" />
          <Text style={tw`text-white font-bold ml-2`}>Submit</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

export default Degree;
