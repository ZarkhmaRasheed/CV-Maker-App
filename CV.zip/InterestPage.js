import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, Alert } from 'react-native';
import tw from 'twrnc';
import {supabase} from './supabase'; // Ensure this file contains your Supabase client initialization

const InterestPage = ({ navigation }) => {
  const [interests, setInterests] = useState([{ interest: '' }]);

  const handleAddInterest = () => {
    setInterests([...interests, { interest: '' }]);
  };

  const handleChange = (index, value) => {
    const updatedInterests = [...interests];
    updatedInterests[index].interest = value;
    setInterests(updatedInterests);
  };

  const handleSubmit = async (index) => {
    const interest = interests[index].interest;
    if (!interest) {
      Alert.alert('Error', 'Please fill out the interest field.');
      return;
      
    }

    try {
      // Insert the interest into the 'Interests' table in Supabase
      const { data, error } = await supabase
        .from('Interests') // Ensure your table name is correct
        .insert([{ interest: interest }]);

      if (error) {
        throw error;
      }

    
    } catch (error) {
      Alert.alert('Error', error.message);
    
    }
    navigation.navigate('Hobby'); 
  };

  return (
    <View style={tw`flex-1 bg-gray-100 p-4`}>
      <ScrollView contentContainerStyle={tw`pb-10`}>
        {interests.map((interest, index) => (
          <View key={index} style={tw`mb-6 bg-white p-6 rounded-lg shadow-lg`}>
            <Text style={tw`text-lg font-bold text-blue-800 mb-4`}>Interest {index + 1}</Text>
            
            {/* Interest Input */}
            <Text style={tw`text-gray-800 font-semibold mb-2`}>Interest</Text>
            <TextInput
              style={tw`p-3 border border-gray-300 rounded mb-4`}
              placeholder="Enter your interest"
              value={interest.interest}
              onChangeText={(text) => handleChange(index, text)}
            />

            {/* Submit Button for each Interest */}
            <TouchableOpacity
              onPress={() => handleSubmit(index)}
              style={tw`bg-blue-500 px-4 py-3 rounded shadow-lg`}
            >
              <Text style={tw`text-white font-bold text-center`}>Submit Interest</Text>
            </TouchableOpacity>
          </View>
        ))}

        {/* Add Interest Button */}
        <TouchableOpacity
          onPress={handleAddInterest}
          style={tw`bg-green-500 px-4 py-3 rounded shadow-lg mt-6`}
        >
          <Text style={tw`text-white font-bold text-center`}>Add Interest</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

export default InterestPage;
