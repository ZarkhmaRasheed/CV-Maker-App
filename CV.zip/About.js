import React from 'react';
import { View, Text, Image, Animated, Easing, ScrollView } from 'react-native';
import tw from 'twrnc';

const AboutUs = () => {
    const scaleValue1 = React.useRef(new Animated.Value(0)).current;
    const scaleValue2 = React.useRef(new Animated.Value(0)).current;
    const scaleValue3 = React.useRef(new Animated.Value(0)).current;
    const scaleValue4 = React.useRef(new Animated.Value(0)).current;

    const startAnimation = (scaleValue) => {
        scaleValue.setValue(0); // Reset the animation before starting
        Animated.timing(scaleValue, {
            toValue: 1,
            duration: 1000,
            easing: Easing.bounce,
            useNativeDriver: true,
        }).start();
    };

    React.useEffect(() => {
        startAnimation(scaleValue1);
        startAnimation(scaleValue2);
        startAnimation(scaleValue3);
        startAnimation(scaleValue4);
    }, []);

    return (
        <ScrollView contentContainerStyle={tw`bg-gray-900 p-6`}>
            {/* Full-page container */}
            <View style={tw`flex justify-center items-center bg-gray-900 p-8 mb-12`}>
                <Animated.View style={{ transform: [{ scale: scaleValue1 }] }}>
                    <Image
                        source={{ uri: 'https://via.placeholder.com/150' }}
                        style={tw`w-40 h-40 rounded-full mb-4`}
                    />
                </Animated.View>
                <Text style={tw`text-4xl font-bold text-white mb-2`}>About Us</Text>
                <Text style={tw`text-lg text-gray-300 text-center mb-6`}>Get to know our mission and values!</Text>
            </View>

            {/* About Information Container */}
            <Animated.View style={{ transform: [{ scale: scaleValue2 }] }}>
                <View style={tw`bg-gray-800 p-6 rounded-lg shadow-xl mb-8`}>
                    <Text style={tw`text-center text-lg font-bold text-white mb-4`}>Our Mission</Text>
                    <Text style={tw`text-gray-300 text-center`}>
                        At AllUnitConverter, our mission is to provide innovative solutions that enhance the lives of our users through technology. We strive to create user-friendly applications that offer real value and improve productivity.
                    </Text>
                </View>
            </Animated.View>

            {/* Company Overview Container */}
            <Animated.View style={{ transform: [{ scale: scaleValue3 }] }}>
                <View style={tw`bg-gray-800 p-6 rounded-lg shadow-xl mb-8`}>
                    <Text style={tw`text-2xl font-bold text-white mb-4`}>Company Overview</Text>
                    <Text style={tw`text-lg text-gray-300 leading-7`}>
                        We are a team of passionate professionals with a shared vision of making everyday tasks simpler through advanced technology. Our team consists of developers, designers, and experts in various domains who work together to create seamless experiences for users.
                    </Text>
                </View>
            </Animated.View>

            {/* Core Values Container */}
            <Animated.View style={{ transform: [{ scale: scaleValue4 }] }}>
                <View style={tw`bg-gray-800 p-6 rounded-lg shadow-xl mb-8`}>
                    <Text style={tw`text-2xl font-bold text-white mb-4`}>Core Values</Text>
                    <Text style={tw`text-lg text-gray-300 leading-7`}>We believe in:</Text>
                    <Text style={tw`text-gray-300 leading-7 mt-4`}>- Innovation: Constantly pushing the boundaries of technology.</Text>
                    <Text style={tw`text-gray-300 leading-7`}>- Integrity: Doing what's right for our users and business.</Text>
                    <Text style={tw`text-gray-300 leading-7`}>- Collaboration: Working together to achieve greater outcomes.</Text>
                    <Text style={tw`text-gray-300 leading-7`}>- User-Centricity: Focusing on user needs and delivering value-driven solutions.</Text>
                </View>
            </Animated.View>

            {/* Footer */}
            <View style={tw`bg-gray-800 p-4 rounded-lg shadow-xl mt-8`}>
                <Text style={tw`text-center text-gray-300 text-sm`}>
                    © 2024 All Unit Converter. All rights reserved.
                </Text>
                <Text style={tw`text-center text-gray-300 text-lg mt-2`}>
                    Empowering users with technology.
                </Text>
            </View>
        </ScrollView>
    );
};

export default AboutUs;