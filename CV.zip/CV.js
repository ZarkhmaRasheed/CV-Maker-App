import React from 'react';
import { View, Text, Image, ScrollView } from 'react-native';
import tw from 'twrnc';

const CVApp = () => {
  return (
    <ScrollView style={tw`bg-gray-100 flex-1`}>
      {/* Header Section */}
      <View style={tw`bg-blue-500 p-6 items-center`}>
        <Image
          source={{ uri: 'https://via.placeholder.com/150' }} // Replace with your photo URL
          style={tw`w-32 h-32 rounded-full border-4 border-white`}
        />
        <Text style={tw`text-white text-2xl font-bold mt-4`}>Jon Doe</Text>
        <Text style={tw`text-white text-lg`}>Software Engineer</Text>
      </View>

      {/* About Section */}
      <View style={tw`p-4`}>
        <Text style={tw`text-xl font-bold text-blue-700 mb-2`}>About Me</Text>
        <Text style={tw`text-gray-700`}>
          Passionate Software Engineer with 5+ years of experience in full-stack development. Proficient in React Native, Node.js, and Python.
        </Text>
      </View>

      {/* Skills Section */}
      <View style={tw`p-4`}>
        <Text style={tw`text-xl font-bold text-blue-700 mb-2`}>Skills</Text>
        <View style={tw`flex-row flex-wrap`}>
          {['React Native', 'JavaScript', 'Python', 'Node.js', 'Git', 'Tailwind CSS'].map((skill, index) => (
            <Text
              key={index}
              style={tw`bg-blue-200 text-blue-700 py-1 px-3 rounded-full m-1 text-sm font-semibold`}
            >
              {skill}
            </Text>
          ))}
        </View>
      </View>

      {/* Work Experience Section */}
    

      {/* Education Section */}
      
      {/* Footer */}
      <View style={tw`bg-blue-500 p-4 mt-4`}>
        <Text style={tw`text-white text-center`}>
         
        </Text>
      </View>
    </ScrollView>
  );
};

export default CVApp;
