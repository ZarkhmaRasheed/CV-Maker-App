// import React, { useState } from 'react';
// import { View, Text, TextInput, TouchableOpacity, ScrollView, Alert } from 'react-native';
// import tw from 'twrnc';
// import { supabase } from './supabase';  // Import the Supabase client

// const Hobby = ({ navigation }) =>{
//   const [hobbies, setHobbies] = useState([{ hobby: '' }]);

//   const handleAddHobby = () => {
//     setHobbies([...hobbies, { hobby: '' }]);
//   };

//   const handleChange = (index, value) => {
//     const updatedHobbies = [...hobbies];
//     updatedHobbies[index].hobby = value;
//     setHobbies(updatedHobbies);
//   };

//   // Function to submit hobby to Supabase
//   const handleSubmit = async (index) => {
//     const hobby = hobbies[index].hobby;
//     if (!hobby) {
//       Alert.alert('Error', 'Please fill out the hobby field.');
//       return;
//     }

//     // Insert the hobby into the Supabase 'hobbies' table
//     const { data, error } = await supabase
//       .from('hobbies') // 'hobbies' is the table name in your Supabase database
//       .insert([
//         { hobby: hobby }, // column name: hobby
//       ]);

//     if (error) {
//       Alert.alert('Error', 'Failed to add hobby: ' + error.message);
//     } else {
//       Alert.alert('Success', `Hobby ${index + 1} added successfully!`);
//       // Optionally, you can refresh the list or clear the input here.
//     }
//     navigation.navigate('Pdetails'); 
//   };

//   return (
//     <View style={tw`flex-1 bg-gray-100 p-4`}>
//       <ScrollView contentContainerStyle={tw`pb-10`}>
//         {hobbies.map((hobby, index) => (
//           <View key={index} style={tw`mb-6 bg-white p-6 rounded-lg shadow-lg`}>
//             <Text style={tw`text-lg font-bold text-blue-800 mb-4`}>Hobby {index + 1}</Text>
            
//             {/* Hobby Input */}
//             <Text style={tw`text-gray-800 font-semibold mb-2`}>Hobby</Text>
//             <TextInput
//               style={tw`p-3 border border-gray-300 rounded mb-4`}
//               placeholder="Enter your hobby"
//               value={hobby.hobby}
//               onChangeText={(text) => handleChange(index, text)}
//             />

//             {/* Submit Button for each Hobby */}
//             <TouchableOpacity
//               onPress={() => handleSubmit(index)}
//               style={tw`bg-blue-500 px-4 py-3 rounded shadow-lg`}
//             >
//               <Text style={tw`text-white font-bold text-center`}>Submit Hobby</Text>
//             </TouchableOpacity>
//           </View>
//         ))}

//         {/* Add Hobby Button */}
//         <TouchableOpacity
//           onPress={handleAddHobby}
//           style={tw`bg-green-500 px-4 py-3 rounded shadow-lg mt-6`}
//         >
//           <Text style={tw`text-white font-bold text-center`}>Add Hobby</Text>
//         </TouchableOpacity>
//       </ScrollView>
//     </View>
//   );
// };

// export default Hobby;


import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, Alert } from 'react-native';
import tw from 'twrnc';
import { supabase } from './supabase';  // Import the Supabase client

const Hobby = ({ navigation }) => {
  const [hobbies, setHobbies] = useState([{ hobby: '' }]);

  const handleAddHobby = () => {
    setHobbies([...hobbies, { hobby: '' }]);
  };

  const handleChange = (index, value) => {
    const updatedHobbies = [...hobbies];
    updatedHobbies[index].hobby = value;
    setHobbies(updatedHobbies);
  };

  // Function to submit all hobbies to Supabase
  const handleSubmitAll = async () => {
    // Filter out empty hobby fields
    const filledHobbies = hobbies.filter(hobby => hobby.hobby.trim() !== '');

    if (filledHobbies.length === 0) {
      Alert.alert('Error', 'Please fill out at least one hobby.');
      return;
    }

    // Insert the hobbies into the Supabase 'hobbies' table
    const { data, error } = await supabase
      .from('hobbies') // 'hobbies' is the table name in your Supabase database
      .insert(filledHobbies.map(hobby => ({ hobby: hobby.hobby })));

    if (error) {
      Alert.alert('Error', 'Failed to add hobbies: ' + error.message);
    } else {
     
      setHobbies([{ hobby: '' }]); // Reset the form after successful submission
    }

    navigation.navigate('Pdetails'); // Navigate to Pdetails screen after submission
  };

  return (
    <View style={tw`flex-1 bg-gray-100 p-4`}>
      <ScrollView contentContainerStyle={tw`pb-10`}>
        {hobbies.map((hobby, index) => (
          <View key={index} style={tw`mb-6 bg-white p-6 rounded-lg shadow-lg`}>
            <Text style={tw`text-lg font-bold text-blue-800 mb-4`}>Hobby {index + 1}</Text>
            
            {/* Hobby Input */}
            <Text style={tw`text-gray-800 font-semibold mb-2`}>Hobby</Text>
            <TextInput
              style={tw`p-3 border border-gray-300 rounded mb-4`}
              placeholder="Enter your hobby"
              value={hobby.hobby}
              onChangeText={(text) => handleChange(index, text)}
            />

            {/* Submit Button for each Hobby */}
            <TouchableOpacity
              onPress={() => handleSubmitAll()} // Submit all hobbies at once
              style={tw`bg-blue-500 px-4 py-3 rounded shadow-lg`}
            >
              <Text style={tw`text-white font-bold text-center`}>Submit All Hobbies</Text>
            </TouchableOpacity>
          </View>
        ))}

        {/* Add Hobby Button */}
        <TouchableOpacity
          onPress={handleAddHobby}
          style={tw`bg-green-500 px-4 py-3 rounded shadow-lg mt-6`}
        >
          <Text style={tw`text-white font-bold text-center`}>Add Hobby</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

export default Hobby;
