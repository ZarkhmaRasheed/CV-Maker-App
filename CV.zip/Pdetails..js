import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, ScrollView } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import tw from 'twrnc';
import { supabase } from './supabase'; // Import the supabase client

const Pdetails = ({ navigation }) =>  {
  const [fatherName, setFatherName] = useState('');
  const [dob, setDob] = useState('');
  const [gender, setGender] = useState('');
  const [maritalStatus, setMaritalStatus] = useState('');
  const [nationality, setNationality] = useState('');
  const [languages, setLanguages] = useState('');

  // Handle form submission
  const handleSubmit = async () => {
    if (!fatherName || !dob || !gender || !maritalStatus || !nationality || !languages) {
      Alert.alert('Error', 'All fields are required!');
      return;
    }

    // Insert data into Supabase
    const { data, error } = await supabase
      .from('personal_details')
      .insert([
        {
          father_name: fatherName,
          dob: dob,
          gender: gender,
          marital_status: maritalStatus,
          nationality: nationality,
          languages_known: languages,
        },
      ]);

    if (error) {
      Alert.alert('Error', 'There was a problem submitting your data.');
    } else {
      Alert.alert('Success', 'Personal details submitted successfully!');
      // Optionally clear the form after submission
      setFatherName('');
      setDob('');
      setGender('');
      setMaritalStatus('');
      setNationality('');
      setLanguages('');
    }
    navigation.navigate('CurriculumVitae'); 
  };

  return (
    <View style={tw`flex-1 bg-blue-50 p-4`}>
      <ScrollView contentContainerStyle={tw`pb-10`}>
        {/* Header */}
        <View style={tw`mt-7 flex-row justify-between items-center mb-6`}>
          <Text style={tw`text-lg font-bold text-blue-800`}>Personal Details</Text>
          <FontAwesome name="user-circle" size={24} color="blue" />
        </View>

        {/* Input Fields */}
        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>Father's Name</Text>
          <TextInput
            style={tw`p-3 border border-gray-300 rounded mb-4`}
            placeholder="Enter Father's Name"
            value={fatherName}
            onChangeText={setFatherName}
          />
        </View>

        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>Date of Birth</Text>
          <TextInput
            style={tw`p-3 border border-gray-300 rounded mb-4`}
            placeholder="Enter Date of Birth"
            value={dob}
            onChangeText={setDob}
          />
        </View>

        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>Gender</Text>
          <TextInput
            style={tw`p-3 border border-gray-300 rounded mb-4`}
            placeholder="Enter Gender"
            value={gender}
            onChangeText={setGender}
          />
        </View>

        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>Marital Status</Text>
          <TextInput
            style={tw`p-3 border border-gray-300 rounded mb-4`}
            placeholder="Enter Marital Status"
            value={maritalStatus}
            onChangeText={setMaritalStatus}
          />
        </View>

        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>Nationality</Text>
          <TextInput
            style={tw`p-3 border border-gray-300 rounded mb-4`}
            placeholder="Enter Nationality"
            value={nationality}
            onChangeText={setNationality}
          />
        </View>

        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>Languages Known</Text>
          <TextInput
            style={tw`p-3 border border-gray-300 rounded mb-4`}
            placeholder="Enter Languages Known"
            value={languages}
            onChangeText={setLanguages}
          />
        </View>

        {/* Submit Button */}
        <TouchableOpacity
          onPress={handleSubmit}
          style={tw`bg-blue-500 px-4 py-3 rounded shadow-lg flex-row items-center justify-center`}
        >
          <FontAwesome name="check-circle" size={20} color="white" />
          <Text style={tw`text-white font-bold ml-2`}>Submit</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

export default Pdetails;
