import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { View, Text } from 'react-native';

// Import screens
import MyTabs from './MyTabs';
import Hobby from './Hobby';
import IntroPage from './IntroPage';
import InterestPage from './InterestPage';
import JobExperience from './JobExperience';
import Projects from './Projects';
import Second from './Second';
import CurriculumVitae from './CurriculumVitae';
import Degree from './Degree';
import Skills from './Skills';
import Pdetails from './Pdetails.';
import About from './About';
import Feedbacks from './Feedbacks';

// Tab Navigator
const Tab = createBottomTabNavigator();
function TabNavigator() {
  return (
    <Tab.Navigator>
      <Tab.Screen name="Home" component={MyTabs} />
      {/* Add more tab screens as needed */}
    </Tab.Navigator>
  );
}

// Drawer Navigator
const Drawer = createDrawerNavigator();
function DrawerNavigator() {
  return (
    <Drawer.Navigator initialRouteName="Home">
      <Drawer.Screen name="Home" component={StackNavigator} options={{ headerShown: false }}
      />
      <Drawer.Screen name="Second" component={Second} />
      <Drawer.Screen name="About" component={About} />
      <Drawer.Screen name="CurriculumVitae" component={CurriculumVitae} />
      <Drawer.Screen name="Feedbacks" component={Feedbacks} />

    </Drawer.Navigator>
  );
}

// Stack Navigator
const Stack = createStackNavigator();
function StackNavigator() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Second" component={Second} options={{ headerShown: false }} />
      <Stack.Screen name="IntroPage" component={IntroPage} options={{ headerShown: true, title: 'Create Resume' }} />
      <Stack.Screen name="MainTabs" component={TabNavigator} options={{ headerShown: false }}/>
      <Stack.Screen name="InterestPage" component={InterestPage} options={{ headerShown: false }} />
      <Stack.Screen name="JobExperience" component={JobExperience} options={{ headerShown: false }} />
      <Stack.Screen name="Projects" component={Projects} options={{ headerShown: false }}/>
      <Stack.Screen name="Degree" component={Degree} options={{ headerShown: false }}/>
      <Stack.Screen name="Skills" component={Skills} options={{ headerShown: false }}/>
      <Stack.Screen name="Hobby" component={Hobby} options={{ headerShown: false }}/>
      <Stack.Screen name="Pdetails" component={Pdetails} options={{ headerShown: false }}/>


    </Stack.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>

      <DrawerNavigator />

    </NavigationContainer>
  );
}
