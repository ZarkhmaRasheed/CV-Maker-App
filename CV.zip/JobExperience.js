import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, ScrollView } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import tw from 'twrnc';
import { supabase } from './supabase';  // Import Supabase client

const JobExperience = ({ navigation }) =>  {
  const [company, setCompany] = useState('');
  const [role, setRole] = useState('');
  const [startMonth, setStartMonth] = useState('');
  const [startYear, setStartYear] = useState('');
  const [endMonth, setEndMonth] = useState('');
  const [endYear, setEndYear] = useState('');
  const [description, setDescription] = useState('');

  // Handle form submission and save data to Supabase
  const handleSubmit = async () => {
    if (!company || !role || !startMonth || !startYear || !endMonth || !endYear || !description) {
      Alert.alert('Error', 'All fields are required!');
      return;
    }

    try {
      const { data, error } = await supabase
        .from('JobExperience')  // Replace 'JobExperience' with your table name
        .insert([
          { company, role, start_month: startMonth, start_year: startYear, end_month: endMonth, end_year: endYear, description },
        ]);

      if (error) {
        Alert.alert('Error', 'Failed to submit the form');
        console.error('Error inserting data:', error);
      } else {
       
        // Reset fields after successful submission
        setCompany('');
        setRole('');
        setStartMonth('');
        setStartYear('');
        setEndMonth('');
        setEndYear('');
        setDescription('');

        navigation.navigate('Projects'); 
      }
    } catch (err) {
      console.error('Unexpected error:', err);
      Alert.alert('Error', 'An unexpected error occurred');
    }
  };

  return (
    <View style={tw`flex-1 bg-blue-50`}>
      <ScrollView contentContainerStyle={tw`p-4`}>
        {/* Header */}
        <View style={tw`mt-7 flex-row justify-between items-center mb-6`}>
          <Text style={tw`text-lg font-bold text-blue-800`}>Add Job Experience</Text>
          <FontAwesome name="briefcase" size={24} color="blue" />
        </View>

        {/* Input Fields */}
        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>Company</Text>
          <TextInput
            style={tw`p-3 border border-gray-300 rounded mb-4`}
            placeholder="Enter company name"
            value={company}
            onChangeText={setCompany}
          />
        </View>

        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>Role</Text>
          <TextInput
            style={tw`p-3 border border-gray-300 rounded mb-4`}
            placeholder="Enter your role"
            value={role}
            onChangeText={setRole}
          />
        </View>

        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>Start Month</Text>
          <TextInput
            style={tw`p-3 border border-gray-300 rounded mb-4`}
            placeholder="Enter start month"
            value={startMonth}
            onChangeText={setStartMonth}
          />
        </View>

        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>Start Year</Text>
          <TextInput
            style={tw`p-3 border border-gray-300 rounded mb-4`}
            placeholder="Enter start year"
            value={startYear}
            keyboardType="numeric"
            onChangeText={setStartYear}
          />
        </View>

        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>End Month</Text>
          <TextInput
            style={tw`p-3 border border-gray-300 rounded mb-4`}
            placeholder="Enter end month"
            value={endMonth}
            onChangeText={setEndMonth}
          />
        </View>

        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>End Year</Text>
          <TextInput
            style={tw`p-3 border border-gray-300 rounded mb-4`}
            placeholder="Enter end year"
            value={endYear}
            keyboardType="numeric"
            onChangeText={setEndYear}
          />
        </View>

        <View style={tw`bg-white rounded-lg p-6 mb-4 shadow-lg`}>
          <Text style={tw`text-gray-800 font-semibold mb-2`}>Description</Text>
          <TextInput
            style={tw`p-3 border border-gray-300 rounded mb-4`}
            placeholder="Describe your responsibilities"
            value={description}
            multiline
            onChangeText={setDescription}
          />
        </View>

        {/* Submit Button */}
        <TouchableOpacity
          onPress={handleSubmit}
          style={tw`bg-blue-500 px-4 py-3 rounded shadow-lg flex-row items-center justify-center`}
        >
          <FontAwesome name="check-circle" size={20} color="white" />
          <Text style={tw`text-white font-bold ml-2`}>Submit</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

export default JobExperience;

