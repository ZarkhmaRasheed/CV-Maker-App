import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import IntroPage from './IntroPage';
import InterestPage from './InterestPage';
import JobExperience from './JobExperience';
import Projects from './Projects';
import Pdetails from './Pdetails.';


const Tab = createBottomTabNavigator();

function MyTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: 'black' }, // Change the header background color to black
        headerTintColor: 'white', // Change the header text color to white
        tabBarStyle: { backgroundColor: 'black' }, // Change the tab bar background color to black
        tabBarActiveTintColor: 'white', // Change the active tab text/icon color to white
        tabBarInactiveTintColor: 'gray', // Change the inactive tab text/icon color to gray
      }}>
      <Tab.Screen
        name="IntroPage"
        component={IntroPage}
        options={{
          tabBarIcon: ({ color, size }) => (
            <FontAwesome5 name="home" size={size} color={color} />
          ),
          tabBarLabel: 'IntroPage',
        }}
      />

      <Tab.Screen
        name="InterestPage"
        component={InterestPage}
        options={{
          tabBarIcon: ({ color, size }) => (
            <FontAwesome5 name="calculator" color={color} size={size} />
          ),
          tabBarLabel: 'InterestPage',
        }}
      />

      <Tab.Screen
        name="JobExperience"
        component={JobExperience}
        options={{
          tabBarIcon: ({ color, size }) => (
            <FontAwesome5 name="plus" color={color} size={size} />
          ),
          tabBarLabel: 'JobExperience',
        }}
      />

      <Tab.Screen
        name="Projects"
        component={Projects}
        options={{
          tabBarIcon: ({ color, size }) => (
            <FontAwesome5 name="coins" color={color} size={size} />
          ),
          tabBarLabel: 'Projects',
        }}
      />


      <Tab.Screen
        name="Pdetails"
        component={Pdetails}
        options={{
          tabBarIcon: ({ color, size }) => (
            <FontAwesome5 name="coins" color={color} size={size} />
          ),
          tabBarLabel: 'Pdetails',
        }}
      />
    </Tab.Navigator>
  );
}

export default MyTabs;

